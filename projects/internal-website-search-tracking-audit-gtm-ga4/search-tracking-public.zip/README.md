# Search Analytics Audit & Rebuild — GTM + GA4

A full audit, diagnosis, and rebuild of search tracking across a multi-property e-commerce site (two domains, two separate GTM containers, two GA4 properties).

This project was inherited from a previous analytics consultancy. On inspection, tracking was broken or unreliable across every search surface despite data appearing to flow into GA4. Every bug was diagnosed and fixed independently — no dev dependency for the GTM/GA4 side, with one scoped developer request for the remaining application-level gap.

---

## The Problem

Search tracking had been set up using GTM's generic auto-event listeners (Form Submit, Element Visibility, Click) rather than explicit dataLayer pushes from the application. This meant:

- GTM was **guessing** at user behavior by reacting to browser events — not being told by the application what actually happened
- Search terms appeared in GA4 only because a separate URL-parsing variable happened to read them from the address bar — the tracking event itself carried no search data
- There was **no way to detect zero-results searches** at all
- Tags were firing on page load, on empty queries, and on every click — not on actual search interactions
- All QA/testing traffic was polluting live reports with no internal traffic filtering in place

---

## What Was Fixed

| Surface | Inherited State | Outcome |
|---|---|---|
| FAQ search | Tag fired on page Initialization, `search_term` always empty | ✅ Fixed in GTM — URL variable, correct trigger, result count + zero-results detection |
| FAQ zero-results detection (v1) | Built on `.contactBlock` element visibility — a persistent CTA on every FAQ page, not a zero-results signal | ✅ Identified as flawed, removed — zero-results now detected via `search_has_results` parameter |
| Empty query param | `contains query=` condition matched `?query=` with no value, misfiring on default page loads | ✅ Fixed with regex requiring non-empty value |
| Result-click tracking | Fired on any click anywhere on a `/search*` page — not scoped to actual result clicks | ✅ Identified as broken, paused |
| Downloads search | Proper dataLayer push already in place | ✅ Confirmed working, no changes needed |
| GA4 reporting hygiene | No internal traffic filter — all QA/testing data polluting reports | ✅ Internal Traffic + Data Filter configured |
| Second property/container | Separate GTM container and GA4 property — fixes did not propagate automatically | ✅ Every fix independently re-diagnosed and re-applied |
| Main search | GTM Form Submit auto-event — no result count, no zero-results detection, fragile | ⏳ Diagnosed, developer ticket written and filed |

---

## The Fix — One Event Schema Across All Surfaces

Replaced fragile auto-event guesswork with one explicit, outcome-aware event that the application fires itself:

```javascript
window.dataLayer = window.dataLayer || [];
window.dataLayer.push({
  event: 'search_performed',
  search_term: '<query>',
  search_context: 'main' | 'faq' | 'downloads',
  search_result_count: <number>,
  search_has_results: <true|false>,
  search_method: 'text_input' | 'filter',
  filter_name: '',
  filter_value: ''
});
```

`search_context` differentiates the surface. `search_has_results` and `search_result_count` capture the outcome — something generic auto-events structurally cannot do.

For surfaces where no application-level push was available (FAQ), the same parameters were approximated client-side in GTM using Custom JavaScript variables reading from the page DOM, with careful URL-based triggering to avoid misfires.

---

## Skills Demonstrated

- Full GTM container audit across multiple containers and properties
- Root cause diagnosis of silently broken tracking (data flowing but incorrect)
- Custom JavaScript variable authoring for DOM-based data extraction
- Regex-based trigger conditions for precision scoping
- GA4 custom dimension strategy and zero-results reporting setup
- Internal traffic filtering for clean reporting data
- Multi-property rollout — independently replicating fixes across separate containers
- Developer ticket writing: clear schema specification, dynamic field reference, before/after explanation

---

## Repo Structure

```
README.md                            — this file
docs/
  bug-log.md                         — every bug found: symptom, root cause, fix, test evidence
  schema.md                          — the corrected search event contract
  gtm-setup.md                       — final GTM configuration: variables, triggers, tags
  ga4-reporting-setup.md             — internal traffic filter + zero-results reporting queries
  ca-rollout-checklist.md            — record of replicating fixes in the second container/property
  developer-ticket.md                — the ticket written for the remaining main search gap
scripts/
  js-variables/
    faq-search-term-from-url.js      — reads search term from URL with referrer fallback
    faq-result-count.js              — reads result count from DOM .resultCounter element
    faq-has-results.js               — boolean wrapper; avoids the .contactBlock false-positive trap
```

---

## Key Decisions Worth Noting

**Why not just patch the existing auto-event setup?**
Patching would have left the fundamental problem — GTM guessing at outcomes — in place, just with more duct tape. The goal was a tracking setup that a new analyst could audit in 6 months and understand immediately, not one that requires tribal knowledge to maintain.

**Why one event name instead of separate events per surface?**
`search_context` as a parameter is cleaner than three separate event names (`faq_search`, `main_search`, `downloads_search`) — it keeps GA4 reporting unified, makes cross-surface comparisons trivial, and means adding a fourth search surface in the future requires no new GTM tags, just a new `search_context` value.

**Why not wait for the developer to fix everything?**
The FAQ surface had everything needed in the URL and DOM to do this properly in GTM alone. Filing a developer ticket to add a dataLayer push for FAQ would have introduced a sprint dependency, delayed reporting, and still left a DOM-fragile implementation. The URL-based approach is actually more reliable for FAQ since the search term is structurally encoded in the URL by the platform — it can't disappear without breaking the search functionality itself.
