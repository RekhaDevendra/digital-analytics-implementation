# GA4 Reporting Setup

## Internal Traffic Filtering

All QA and testing traffic was found polluting standard GA4 reports. GTM Preview mode does not prevent tags from sending real hits to GA4 — it only makes firing visible. Every search performed during debugging was logged as a real event.

### Setup (per GA4 property — each domain is a separate property)

1. **Admin → Data Streams → [stream] → Configure Tag Settings → Show all → Define Internal Traffic**
2. Add a rule:
   - Rule name: e.g. `Analyst Testing`
   - Match type: `IP address equals`
   - Add all IP addresses used for testing (home, office, etc.)
3. **Admin → Data Settings → Data Filters → Create Filter**
   - Filter type: `Internal Traffic`
   - Operation: `Exclude`
   - Filter state: **Testing** first — verify it's correctly catching your traffic before switching to Active
4. Verify in **Reports → Realtime** that your own sessions show `traffic_type: internal`
5. Switch filter from Testing to **Active**

> This must be configured separately per GA4 property. Already-collected data is not retroactively removed — only new incoming data is affected.

---

## Custom Dimensions Required

Register these in **Admin → Custom Definitions → Custom Dimensions** before building reports:

| Dimension name | Scope | Event parameter | Priority |
|---|---|---|---|
| Search Has Results | Event | `search_has_results` | High — required for zero-results reporting |
| Search Context | Event | `search_context` | High — required to differentiate surfaces |
| Search Result Count | Event | `search_result_count` | Lower — useful later for result quality analysis |

---

## Zero-Results Rate Report

**GA4 → Explore → Free Form**

- Rows: `search_has_results`, `search_term`
- Values: Event count
- Filter: Event name = `view_search_results`, `search_context` = `faq`
- Sort: Event count descending
- Secondary filter: `search_has_results = false` to isolate failing searches

Result: a ranked list of every search term that returned zero results and how often — the direct input for search improvement prioritization.

**Zero-results rate calculation:**
```
false count / (true count + false count) × 100
```

---

## Notes on Historical Data

Data collected before the fixes in this project used the old broken tracking — `search_term` was often empty, `search_has_results` and `search_result_count` did not exist. Meaningful analysis starts from the date the corrected tracking was published. Segment by date in all reports to avoid mixing pre-fix and post-fix data.
