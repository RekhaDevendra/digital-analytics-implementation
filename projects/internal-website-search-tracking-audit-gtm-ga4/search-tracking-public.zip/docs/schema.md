# Search Event Schema

## Event Name

`search_performed` — one event for every search interaction across all surfaces.

`search_context` differentiates where the search happened. `search_has_results` captures the outcome. This keeps GA4 reporting unified — one event, sliceable by any dimension — rather than requiring separate reports for different event names.

## Field Reference

| Field | Type | Required | Description | Example |
|---|---|---|---|---|
| `search_term` | string | yes | The query the user typed | `'shower pan'` |
| `search_context` | string | yes | Which search surface | `'main'`, `'faq'`, `'downloads'` |
| `search_result_count` | number | yes | Total results returned | `44` |
| `search_has_results` | boolean | yes | `true` if count > 0 | `true` |
| `search_method` | string | yes | How the search was triggered | `'text_input'`, `'filter'` |
| `filter_name` | string | if filter used | Which filter category | `'document_type'` |
| `filter_value` | string | if filter used | Selected filter value | `'PDF'` |

## Per-Surface Implementation

### Main Search
Application-level dataLayer push — see `developer-ticket.md`. Pending implementation.

### FAQ Search
No application-level push available. Implemented client-side in GTM:
- `search_term` — read from `?query=` URL parameter via Custom JavaScript variable, with referrer fallback
- `search_result_count` / `search_has_results` — read from `.resultCounter` DOM element via Custom JavaScript variables
- Trigger: Page View, scoped to `{{Page URL}} matches RegEx [?&]query=[^&]+` to prevent misfires on empty/default states

### Downloads Search
Pre-existing dataLayer push (`download_search` event, legacy naming kept as-is). Carries equivalent fields including `download_document_type` and `download_file_type` specific to that surface.

## Why Explicit dataLayer Pushes, Not GTM Auto-Events

GTM auto-events (Form Submit, Click, Element Visibility) react to generic browser events. They only know *that* something happened — not whether it succeeded, how many results came back, or what the context was.

An explicit dataLayer push is the application declaring "a search just completed, here is the outcome" — at the exact moment it happens. This is:

- **Resilient** — doesn't break when developers restructure HTML or rename CSS classes
- **Outcome-aware** — captures result count and success/failure, which auto-events cannot
- **Alertable** — `search_has_results: false` spikes can be monitored directly in GA4
- **Scalable** — adding a new search surface requires no new GTM tags, just a new `search_context` value
