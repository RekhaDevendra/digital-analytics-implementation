# GTM Setup Runbook

Complete configuration reference for rebuilding this setup in any GTM container. Used to replicate the fixes in the second container (see `ca-rollout-checklist.md`).

---

## Variables

### Custom JavaScript Variables

#### `JS - FAQ Search Term from URL`
Reads the search term from the `query=` URL parameter. Falls back to the referrer URL to handle cases where the URL resets after a zero-results state.

```javascript
function() {
  var url = window.location.search;
  var match = url.match(/[?&]query=([^&]*)/);
  if (match) return decodeURIComponent(match[1]);

  var ref = document.referrer;
  var refMatch = ref.match(/[?&]query=([^&]*)/);
  return refMatch ? decodeURIComponent(refMatch[1]) : '(not set)';
}
```

#### `JS - FAQ Result Count`
Reads the numeric result count from `.resultCounter` in the DOM.

```javascript
function() {
  var el = document.querySelector('.resultCounter');
  if (!el) return 0;
  var text = el.innerText.replace(/[^0-9]/g, '');
  return text ? parseInt(text) : 0;
}
```

#### `JS - FAQ Has Results`
Boolean version of the above. Returns `false` if count is 0 or element not found.

```javascript
function() {
  var el = document.querySelector('.resultCounter');
  if (!el) return false;
  var text = el.innerText.replace(/[^0-9]/g, '');
  return text && parseInt(text) > 0 ? true : false;
}
```

> ⚠️ Do not use element visibility on `.contactBlock` for zero-results detection — that element is a persistent "contact us" CTA shown on every FAQ page regardless of result count. See `bug-log.md` #2.

### Data Layer Variables (for main search, once developer push is live)

| Variable Name | Data Layer Key |
|---|---|
| `dlv - search_term` | `search_term` |
| `dlv - search_context` | `search_context` |
| `dlv - search_result_count` | `search_result_count` |
| `dlv - search_has_results` | `search_has_results` |
| `dlv - search_method` | `search_method` |
| `dlv - filter_name` | `filter_name` |
| `dlv - filter_value` | `filter_value` |

---

## Triggers

### `pageview - faq_search_results`
- Type: Page View, Some Page Views
- Conditions (all must be true):
  - `{{Page URL}}` contains `/search/faq`
  - `{{Page URL}}` matches RegEx `[?&]query=[^&]+`

> The regex (not `contains query=`) is intentional — the simpler `contains` condition matches `?query=` with an empty value, causing the tag to fire on default page loads with no search performed. See `bug-log.md` #3.

### ~~`visibility - faq_zero_results`~~ — DEPRECATED
Do not rebuild. `.contactBlock` is not a zero-results-specific element. See `bug-log.md` #2.

### `custom - search_performed` (main search, pending developer implementation)
- Type: Custom Event
- Event name: `search_performed`

---

## Tags

### `GA4 - FAQ Search Results` ✅ Live
- Type: GA4 Event
- Event Name: `view_search_results`
- Trigger: `pageview - faq_search_results`
- Parameters:

| Parameter | Value |
|---|---|
| `search_term` | `{{JS - FAQ Search Term from URL}}` |
| `page_location` | `{{Page URL}}` |
| `search_context` | `faq` (hardcoded) |
| `search_result_count` | `{{JS - FAQ Result Count}}` |
| `search_has_results` | `{{JS - FAQ Has Results}}` |

This single tag handles both successful searches and zero-results searches. Distinguish them in GA4 via the `search_has_results` parameter — no separate zero-results event needed.

### ~~`GA4 - faq_zero_results`~~ — PAUSED
Built on the deprecated `.contactBlock` trigger. Kept paused (not deleted) for reference.

### `GA4 - search_performed` ⏳ Dormant — awaiting developer push
- Type: GA4 Event
- Event Name: `view_search_results`
- Trigger: `custom - search_performed`
- Parameters: all `dlv -` variables mapped 1:1 to matching parameter names
- Confirmed not firing in testing — nothing currently pushes `search_performed` to the dataLayer

### ~~`GA4 - search_result_click`~~ — PAUSED (broken)
Trigger condition checked the page URL, not the clicked element. Fired on every click anywhere on a search page. Needs a rebuild scoped to an actual result item's CSS selector.

---

## QA Checklist

- [ ] Search FAQ with results → tag fires, `search_term` populated, `search_has_results: true`, correct `search_result_count`
- [ ] Search FAQ with no results → same tag fires, `search_has_results: false`, `search_result_count: 0`
- [ ] Land on FAQ page fresh, no search → tag does NOT fire
- [ ] Navigate to `/search/faq?query=` (empty) → tag does NOT fire
- [ ] FAQ tag does NOT fire on main search page
- [ ] `GA4 - faq_zero_results` is paused and does not appear in Tags Fired
- [ ] `GA4 - search_result_click` is paused
- [ ] (Once dev push live) Main search → `GA4 - search_performed` fires with all fields populated
