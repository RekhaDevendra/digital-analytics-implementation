# Second Container/Property Rollout

The site runs on two separate domains, each with its own GTM container and GA4 property. No fixes propagate between them automatically — every change had to be independently re-applied.

**Status: Complete.**

---

## Pre-existing State Found

The second container already had a `GA4 - FAQ Search Results` tag — built by the same previous consultancy — but with the **identical bugs** found in the first container:

- Firing on page Initialization, not on actual search
- A zero-results tag built on the same flawed `.contactBlock` element visibility logic
- Same `contains query=` empty-value vulnerability

This confirmed the bugs were systemic across the entire setup, not isolated mistakes.

---

## Steps Completed

- [x] Confirmed URL patterns and DOM structure identical between both domains — same fix applicable without modification
- [x] Created all three JS variables (`faq-search-term-from-url`, `faq-result-count`, `faq-has-results`)
- [x] Created `pageview - faq_search_results` trigger with regex condition
- [x] Rewired existing `GA4 - FAQ Search Results` tag: swapped trigger, repointed all parameters to JS variables
- [x] Paused `GA4 - faq_zero_results`
- [x] Paused `GA4 - search_result_click`
- [x] QA confirmed: zero-results search, successful search, empty-query landing — all correct
- [x] Internal Traffic + Data Filter configured in second GA4 property
- [x] Published

---

## Main Search — Pending (Both Containers)

The developer ticket covers the dataLayer push for main search. Once implemented, the dormant `GA4 - search_performed` tag and `dlv -` variables (already built in the first container) will need to be replicated in the second container and activated in both.
