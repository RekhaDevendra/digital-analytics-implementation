# Developer Ticket — Main Search dataLayer Implementation

*Note: This is a sanitized version of the ticket filed internally. JIRA reference and internal URLs have been removed.*

---

## Background

After a full GTM audit we confirmed:
- Downloads search tracking — working correctly, no changes needed
- FAQ search tracking — fixed entirely in GTM, now working
- Main search — this is the only remaining gap

The main search currently fires via GTM's generic Form Submit auto-event with no structured data. Search terms appear in GA4 only because a separate mechanism reads them from the page URL after the fact — the tracking event itself carries no search outcome data.

## The Problem With The Current Approach

- Tied to DOM structure — if the search box HTML changes, tracking silently breaks
- No result count, no zero-results detection structurally possible
- GTM is guessing at outcomes rather than the application explicitly reporting them

## What We Need

A proper dataLayer push that the website sends the moment search results load — telling us directly what happened, instead of GTM inferring it from a generic form submit.

## Implementation

**URL:** `/search?text=`
**Fire on:** page load

```javascript
window.dataLayer = window.dataLayer || [];
window.dataLayer.push({
  event: 'search_performed',
  search_term: '<dynamic: search query from URL text= parameter>',
  search_context: 'main',
  search_result_count: <dynamic: total number of results>,
  search_has_results: <dynamic: true if count > 0, false if count = 0>,
  search_method: 'text_input',
  filter_name: '',
  filter_value: ''
});
```

**Field reference:**

| Field | What to pass | Example |
|---|---|---|
| `search_term` | Query from URL `text=` parameter | `'shower pan'` |
| `search_result_count` | Total results the page returns | `44` |
| `search_has_results` | `true` if count > 0, `false` if 0 | `true` |

## Zero Results UX Fix

When the main search returns 0 results the page renders completely blank — no message shown to users at all. Confirmed by DOM inspection — no element or class exists for this state.

Please add and show only when `search_result_count = 0`:

```html
<div class="search-no-results">
  No results found for your search. Try different keywords or browse our products.
</div>
```

This fixes the UX gap and gives GTM a CSS hook for zero-results detection.

## Why This Matters

Right now we can see search usage and conversions both improved after a recent deployment, but we can't tell whether search is driving those conversions or measure the difference between users who find what they're searching for versus those who don't. This data will let us show:

- Which keywords users are searching
- Which searches return zero results
- Whether recent search fixes changed user behavior
- Zero results rate before and after deployment

## After Implementation

1. QA in GTM preview, then deprecate the old form submit tracking
2. GA4 report built to monitor search performance
3. Automated alert for zero-results rate spikes
