# Bug Log

Every bug identified during the audit, with root cause, fix, and verification evidence.

---

## Bug #1 — FAQ Search Tag Fired on Page Load, Not on Actual Search

**Symptom**
The FAQ search tag was firing on every page load (GTM `Initialization` message), not when a user actually performed a search. `search_term` arrived empty in GA4 on every hit.

**Root Cause**
The tag's trigger was a Custom Event matching `view_search_results` — but nothing on the FAQ page ever pushed that event to the dataLayer. GTM fell back to firing the tag on `Initialization`. The `search_term` parameter was wired to a Data Layer Variable (`dlv - search_term`) that nothing populated, so it was always empty.

Search terms had appeared historically in GA4 only because a separate URL-parsing mechanism was reading `?query=` from the address bar after the fact — the tag firing and the search term arriving were two disconnected things that coincidentally produced plausible-looking data.

**Fix**

1. Built a Custom JavaScript variable to read the search term directly from the URL, with a referrer fallback for edge cases:

```javascript
function() {
  var url = window.location.search;
  var match = url.match(/[?&]query=([^&]*)/);
  if (match) return decodeURIComponent(match[1]);

  var ref = document.referrer;
  var refMatch = ref.match(/[?&]query=([^&]*)/);
  return refMatch ? decodeURIComponent(refMatch[1]) : '(not set)';
}
```

2. Replaced the trigger with a Page View scoped to actual FAQ search results:

```
Type: Page View, Some Page Views
Conditions:
  {{Page URL}} contains /search/faq
  {{Page URL}} matches RegEx [?&]query=[^&]+
```

3. Repointed `search_term` parameter from `{{dlv - search_term}}` to the new JS variable.

**Verified**
Multiple real searches confirmed in GTM Preview + GA4 DebugView:
- `search_term: ditra` → `search_has_results: true`, `search_result_count: 100`
- `search_term: ff` → `search_has_results: false`, `search_result_count: 0`

---

## Bug #2 — Zero-Results Tag Built on a False Premise

**Symptom**
A `search_zero_results` tag was firing on searches that returned 100 results, and on plain page landings with no search performed at all — not just on genuine zero-results searches.

**Root Cause**
The trigger watched for visibility of a `.contactBlock` element ("Didn't find what you're looking for? Ask us a question"), based on the observation that it appeared on a zero-results page during initial testing.

On further investigation: **this element is a persistent CTA present on every FAQ page regardless of result count.** It renders below the result list whether there are 0 results or 100. The initial test created a false correlation — on a zero-results page, this block is more immediately visible because there's little content above it, but it's not actually conditional on zero results.

**Fix**
Paused the tag and its trigger. Zero-results detection moved into the main search tag using `JS - FAQ Has Results` (a Custom JavaScript variable reading `.resultCounter` from the DOM), surfaced as a `search_has_results: true/false` parameter on the same `view_search_results` event.

Zero-results reports are built in GA4 Explore by segmenting on `search_has_results = false` — no separate event name needed.

**Note for future work**
The `.contactBlock` trigger approach would be valid if the page ever adds a genuinely conditional zero-results element. Until then, reading `.resultCounter` directly is more reliable.

---

## Bug #3 — Empty `query=` Parameter Misfiring as a Valid Search

**Symptom**
A page load at `/search/faq?query=` (empty value, nothing after the equals sign) was firing the FAQ search tag and being logged in GA4 as a successful search with `search_has_results: true` and a full result count.

**Root Cause**
The trigger condition `{{Page URL}} contains query=` matches any URL containing that exact substring — including `?query=` with nothing after it. The FAQ page's default state (showing all FAQs with no search applied) can sometimes load with an empty `query=` parameter, which satisfied the condition and fired the tag.

**Fix**
Changed the second trigger condition from a `contains` match to a regex requiring at least one character after the equals sign:

```
Before: {{Page URL}} contains query=
After:  {{Page URL}} matches RegEx [?&]query=[^&]+
```

**Verified**
Navigated directly to `/search/faq?query=` in GTM Preview after the fix — confirmed the search tag did NOT fire. Re-tested with a real search term immediately after to confirm genuine searches still fired correctly.

---

## Bug #4 — Result-Click Tracking Fired on Any Click, Anywhere on a Search Page

**Symptom**
A `search_result_click` event was firing every time the search input field was clicked (just placing cursor, no typing), as well as on filter dropdowns, whitespace, and any other click on the page.

**Root Cause**
The trigger condition was `gtm.click contains /search` — this checks the **current page URL**, not the element that was clicked. Any click anywhere on a page whose URL contained `/search` satisfied the condition, regardless of whether an actual search result was interacted with.

**Fix**
Tag paused. A correct implementation requires inspecting the CSS structure of an actual search result item and scoping the trigger to that specific element — the same precision-targeting approach used for the other fixes in this log. Deprioritized below the main search developer ticket; flagged as a follow-up.

---

## Bug #5 — Second Property/Container Had All the Same Bugs

**Symptom**
After fixing all of the above in the first GTM container, the equivalent second container (separate domain, separate GTM container ID, separate GA4 property) still exhibited identical broken behavior.

**Root Cause**
The two domains run on entirely separate GTM containers under the same account, with separate GA4 properties. No configuration, publish, or fix in one propagates to the other automatically.

**Fix**
Every fix in this log was independently re-diagnosed and re-applied in the second container, using the same variables, trigger logic, and tag structure. The DOM structure and URL patterns were confirmed to be identical between the two properties before applying, to ensure the same logic worked without modification.

This also confirmed the bugs were systemic — not a one-off mistake on one property, but a consistent pattern across everything the previous consultancy had built.
